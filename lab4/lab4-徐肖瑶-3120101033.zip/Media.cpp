#include "Media.h"

Media::Media(string& tit, int k) : title(tit), kind(k)
{}
Media::~Media(){}